# Mr. Do! driver port for [Chusogar/dsp-cpp](https://github.com/Chusogar/dsp-cpp)

This package ports the **Mr. Do!** arcade driver from
[leniad/dsp-emulator](https://github.com/leniad/dsp-emulator)
(`src/arcade/mrdo_hw.pas`) into the C++17 + SDL2 emulator **dsp-cpp**.

> **Note:** This cloud agent was started on `Chusogar/EmulatorKit` and does not
> have write access to `Chusogar/dsp-cpp`. Apply the patch (or copy the files)
> into that repository and open the PR there.

## What was ported

| Component | Origin | New files in dsp-cpp |
| --- | --- | --- |
| Mr. Do! driver | `mrdo_hw.pas` | `src/drivers/mrdo.{h,cpp}` |
| Z80 @ 4.1 MHz | existing `src/cpu/z80` | reused |
| Dual SN76496 | existing `src/sound/sn76496` | reused |
| Gfx / palette | `gfx_engine` / PROM DAC | via `src/video/gfx` |

Also wired into `src/main.cpp`, `CMakeLists.txt`, `README.md` and unit tests.

Hardware covered from the Pascal unit:

- Memory map (ROM, dual VRAM, sprite RAM, work RAM, scroll regs)
- Protection read at `$9803` (returns `memory[HL]`)
- Dual tilemaps with priority bit and independent scroll
- 64 sprites with PROM colour lookup
- Inputs / cocktail and two DIP banks (defaults `$DF` / `$FF`)
- IRQ on scanline 224, 262 lines @ ~59.94 Hz

## Apply to dsp-cpp

Preferred — fetch the ready-made commit from the git bundle (requires
dsp-cpp `main` at `d359849` or later that contains that commit as ancestor):

```bash
cd dsp-cpp
git fetch /path/to/dsp-cpp-mrdo/mrdo-driver.bundle cursor/mrdo-driver-7ed5:cursor/mrdo-driver-7ed5
git checkout cursor/mrdo-driver-7ed5
cmake -S . -B build -DCMAKE_BUILD_TYPE=Release
cmake --build build -j
ctest --test-dir build
./build/dsp --game mrdo /path/to/mrdo.zip
git push -u origin cursor/mrdo-driver-7ed5   # then open the PR on dsp-cpp
```

Alternatives:

```bash
git checkout -b cursor/mrdo-driver-7ed5
git apply /path/to/dsp-cpp-mrdo/0001-Add-Mr-Do-arcade-driver.patch
# or copy the files under src/, tests/, CMakeLists.txt and README.md over the tree
```

The commit SHA is recorded in `SOURCE_COMMIT.txt` (built against dsp-cpp `d359849`).

## Run

```bash
./build/dsp --game mrdo /path/to/mrdo.zip
./build/dsp --game mrdo --dip 0:0xdf --dip 1:0xff /path/to/mrdo.zip
```

ROM set (parent `mrdo`): `a4-01.bin`, `c4-02.bin`, `e4-03.bin`, `f4-04.bin`,
`s8-09.bin`, `u8-10.bin`, `r8-08.bin`, `n8-07.bin`, `h5-05.bin`, `k5-06.bin`,
`u02--2.bin`, `t02--3.bin`, `f10--1.bin`.

## Contents of this package

- `mrdo-driver.bundle` — preferred: fetchable git commit for dsp-cpp
- `0001-Add-Mr-Do-arcade-driver.patch` — single commit patch against dsp-cpp `main`
- Full copies of every new/modified file for review without applying the patch
- Updated `CMakeLists.txt`, `README.dsp-cpp.md` (project README) and `tests/tests.cpp`

# dsp-cpp

C++17 + SDL2 port of [dsp-emulator](https://github.com/leniad/dsp-emulator) (Free Pascal).
Supported games: **Bagman** (Valadon Automation, 1982), **Mikie** (Konami, 1984),
**Gauntlet** (Atari, 1985), **Double Dragon** and **Double Dragon II** (Technos, 1987/1988).
It also emulates the **ZX Spectrum 48K** and **Amstrad CPC 464/664/6128** home
computers (Sinclair 1982, Amstrad 1984/85/85).

To add another machine follow [docs/adding-a-driver.md](docs/adding-a-driver.md), which
explains the port workflow and comes with a driver skeleton (`tools/new_driver.py`).

## What is ported

| Component | Origin | Notes |
| --- | --- | --- |
| Z80 CPU | `src/cpu/z80/nz80.pas` | Passes the `zexdoc` instruction exerciser (67/67) |
| M6809 CPU | `src/cpu/m6809.pas` | Mikie main CPU |
| AY-3-8910 PSG | `src/snd/ay_8910.pas` | 44100 Hz mono output |
| SN76496 PSG | `src/snd/sn_76496.pas` | Two chips in Mikie |
| PAL16R6 protection | `src/arcade/misc/bagman_pal.pas` | Original fuse map |
| Graphics decoding, palette | `src/misc/gfx_engine.pas`, `pal_engine.pas` | Bit-level layouts and resistor weights |
| Bagman driver | `src/arcade/bagman_hw.pas` | Memory map, video, inputs, DIP switches |
| Mikie driver | `src/arcade/mikie_hw.pas` | M6809 + sound Z80, PROM colour lookup tables, sprites |
| M68000/68010 CPU | `src/cpu/m68000.pas` | Gauntlet main CPU |
| M6502 CPU | `src/cpu/m6502.pas` | Gauntlet sound CPU |
| YM2151 FM, POKEY | `src/snd/fm_2151.pas`, `src/snd/pokey.pas` | Gauntlet sound board |
| SLAPSTIC | `src/arcade/misc/slapstic.pas` | Types 101-107, bank switched protected ROM |
| Atari motion objects | `src/arcade/misc/atari_mo.pas` | SLIP based sprite lists |
| Gauntlet driver | `src/arcade/gauntlet_hw.pas` | Memory map, playfield/char/sprite video, EEPROM, sound communication |
| HD63701Y MCU | `src/cpu/m680x.pas` | Double Dragon sub CPU: internal RAM/ROM, I/O ports, output compare timer |
| MSM5205 ADPCM | `src/snd/msm5205.pas` | Two chips in Double Dragon |
| OKI MSM6295 | `src/snd/oki6295.pas` | Double Dragon II sample player |
| Double Dragon driver | `src/arcade/doubledragon_hw.pas` | Both variants: banked ROM, shared RAM, scroll, sprites, sound CPUs |
| Spectrum ULA | `src/computer/spectrum_hw.pas` | Keyboard matrix, border, one bit beeper, EAR input, contended timing |
| Spectrum driver | `src/computer/spectrum_hw.pas`, `spectrum_misc.pas` | 48K memory map, display file with attributes and flash, Kempston joystick |
| Tape player | `src/misc/tap_tzx.pas` | `.tap` blocks and `.tzx` images (turbo, pure tone/data, direct recording, pauses, loops), hooked to the ROM loader |
| Intel 8255 PPI | `src/misc/ppi8255.pas` | Generic 3-port chip, used by the Amstrad CPC |
| uPD765/NEC765 FDC | `src/devices/upd765.pas` | Command state machine (read/write data, read track, read ID, seek, recalibrate, sense drive/interrupt), Amstrad CPC wiring (motor + status/data ports only) |
| .dsk/.edsk loader | `src/misc/disk_file_format.pas` | Standard and Extended CPCEMU disk images, weak/multi sector protection, CRC based sector-size patches (Titus the Fox, Prehistorik) |
| Amstrad CPC driver | `src/ordenadores/amstrad_cpc.pas` | CRTC 6845 (modes 0/1/2, HSYNC/VSYNC, vertical adjust), gate array (pens, palette, ROM/RAM banking, 300 Hz interrupt), PPI-driven AY-3-8910 keyboard scan, CDT/TZX cassette, uPD765 floppy disk (see limitations below) |
| Front end | `src/misc/main_engine.pas` | SDL2 window, texture, audio queue, keyboard |

### Amstrad CPC scope

The 464/664/6128 driver covers the CPU, video (all three modes plus border),
Gate Array, PPI, AY-3-8910, cassette and floppy disk loading, but leaves out
of scope: the Dandanator cartridge, localized ROM variants (French/Spanish/
Danish), the CPC Plus/512K silicon-disk RAM expansions, and (within the FDC)
the Oric `.dsk`/`.mfm` variants and the Lenslock code-wheel protection (which
shows a UI dialog on the source engine). The keyboard matrix maps every
letter, digit, arrow, Enter/Space/Backspace/Tab/Escape/Shift/Ctrl/CapsLock key,
but not the CPC's shift+digit punctuation symbols or the numeric keypad.

### Floppy disk

The 664/6128 (with `amsdos.rom`) can load standard and Extended `.dsk`/`.edsk`
images into drive A with `--disk`. The controller only implements the uPD765
commands the source engine's `upd765.pas` does (no DMA/terminal count, and
writes update FDC status/protection flags but do not persist sector data back
to the image, matching the reference). A 464 has no disk drive on real
hardware either, so loading one there is rejected.

Verified against real `cpc6128.rom`/`amsdos.rom`: RECALIBRATE, SEEK, SENSE
INTERRUPT STATUS, READ ID and READ TRACK all work end to end (confirmed with
the Z80 running the real AMSDOS ROM). READ TRACK — the whole-track sequential
read most custom CPC game loaders use — reads every sector regardless of
where the ID search last left off, so `.dsk` images built around fast loaders
(the overwhelming majority of released games) load correctly. AMSDOS's own
`CAT`/`RUN"..."` commands locate a file by ID search (`READ DATA`/`READ ID`),
whose search state (`sector_actual` in `upd765.pas`) only advances on a
`READ ID` or an exact match, never resets on `SEEK`/`RECALIBRATE`, and gives
up after checking a single sector rather than scanning the rest of the
rotation — ported byte for byte from the source engine. In practice this
means an interactive `CAT` can need several `Retry` presses (or may not
succeed) depending on which sector the previous access left the search on;
this is the source engine's own documented shape for that code path, not a
deviation introduced by this port.

The two real joystick ports are wired straight into keyboard matrix rows 6 and
9 on real hardware (row 6 also has R/T/G/F/B/V/5/6, row 9 also has Backspace),
and this driver reproduces that faithfully — but the shared SDL front end
hard-codes joystick 1/2 to fixed scancodes for arcade games (space, arrows,
R/F/D/G/A/S...), which would otherwise corrupt ordinary typing on a keyboard
machine. `--dip 1:1` opts back into the joysticks for the handful of CPC games
that need one; leave it unset (or `--dip 1:0`) to type normally.

## Building

Requirements: CMake >= 3.16, a C++17 compiler, SDL2 and zlib.

```bash
sudo apt-get install cmake libsdl2-dev zlib1g-dev   # Debian/Ubuntu
cmake -S . -B build -DCMAKE_BUILD_TYPE=Release
cmake --build build -j
```

This produces `build/dsp` and the unit test binary `build/dsp_tests`.

## Running

ROMs are **not** included. Point the emulator to a `bagman.zip` set or to a directory
holding the individual files:

```bash
./build/dsp /path/to/bagman.zip
./build/dsp --scale 3 --dip 0xfe /path/to/roms/bagman/
./build/dsp --game mikie /path/to/mikie.zip
./build/dsp --game gauntlet /path/to/gauntlet.zip
./build/dsp --game ddragon /path/to/ddragon.zip
./build/dsp --game ddragon2 /path/to/ddragon2.zip
./build/dsp --game spectrum48 --tape /path/to/game.tzx /path/to/48.rom
./build/dsp --game cpc6128 /path/to/cpc6128.rom
./build/dsp --game cpc464 --tape /path/to/game.cdt /path/to/cpc464.rom
./build/dsp --game cpc6128 --disk /path/to/game.dsk /path/to/cpc6128.rom
```

The game is taken from `--game` (`bagman`, `mikie`, `gauntlet`, `ddragon`,
`ddragon2`, `spectrum48`, `cpc464`, `cpc664` or `cpc6128`); when omitted it is
guessed from the ROM set name. Gauntlet accepts both the four player parent set
(SLAPSTIC 104) and the two player `136041-xxx` set (SLAPSTIC 107).

Required files: `e9_b05.bin`, `f9_b06.bin`, `f9_b07.bin`, `k9_b08.bin`, `m9_b09s.bin`,
`n9_b10.bin`, `c1_b01.bin`, `e1_b02.bin`, `f1_b03s.bin`, `j1_b04.bin`, `p3.bin`, `r3.bin`.

Amstrad CPC ROMs are **not** bundled either (`cpc464.rom`, `cpc664.rom` or
`cpc6128.rom`, each the 32K OS+BASIC image, plus the optional 16K `amsdos.rom`
for the 664/6128 disk BASIC extensions, auto-loaded from the same directory or
zip when present).

Options:

```
--game NAME        machine to run: bagman, mikie, gauntlet, ddragon, ddragon2,
                   spectrum48, cpc464, cpc664 or cpc6128
--scale N          window scale factor (default 3)
--dip [BANK:]VALUE DIP switch byte, decimal or 0x hex (bagman: one bank,
                   mikie: 0=A coinage, 1=B gameplay, 2=C flip screen;
                   gauntlet: service switch;
                   double dragon: 0=A coinage/cabinet, 1=B gameplay;
                   cpc: bank 0 non-zero = colour monitor, 0 = green monitor;
                   bank 1 non-zero = enable the joysticks, see below)
--mute             disable audio
--fullscreen       start in full screen
--screenshot FILE  headless mode: render frames and write FILE (BMP)
--frames N         frames to run in headless mode (default 300)
--tape FILE        tape image to insert, .tap/.tzx (spectrum48) or .tap/.tzx/.cdt
                   (cpc464/cpc664/cpc6128)
--disk FILE        .dsk/.edsk floppy image for drive A (cpc664/cpc6128 only)
```

### ZX Spectrum 48K

The machine needs the 16 KiB Sinclair ROM, given as a plain `48.rom` image, a zip or a
directory holding it (Debian/Ubuntu ship it in the `spectrum-roms` package):

```bash
./build/dsp --game spectrum48 /usr/share/spectrum-roms/48.rom
./build/dsp --game spectrum48 --tape jetpac.tzx /usr/share/spectrum-roms/48.rom
```

The host keyboard is mapped one to one onto the Spectrum matrix (Left/Right Ctrl are
symbol shift, Shift is caps shift), so `P` is not the pause key here: use `F2`. The
arrows and Left Ctrl are also read as a Kempston joystick. A tape given with `--tape`
plays by itself whenever the ROM loader is running, so typing `LOAD ""` and pressing
Enter loads it. Both `.tap` and `.tzx` images work: the `.tzx` player handles standard
and turbo blocks, pure tones, pulse sequences, pure data, direct recordings, pauses,
signal level changes, jumps and loops. Games that only play under a custom loader still
need the loader to be running, and the CSW (`$18`) and generalized data (`$19`) blocks
are skipped. A "stop the tape" block only pauses for two seconds, because the machine
restarts the tape whenever the loader runs.

### Controls

| Key | Action |
| --- | --- |
| Arrows | Player 1 movement |
| Left Ctrl / Space | Player 1 button 1 |
| Left Alt / Z | Player 1 button 2 |
| X | Player 1 button 3 (Double Dragon jump) |
| D / G / R / F | Player 2 movement |
| A / S | Player 2 buttons |
| Q | Player 2 button 3 |
| 1, 2 | Start 1P / 2P |
| 5, 6 | Insert coin 1 / 2 |
| P | Pause (F2 on the Spectrum, whose keyboard uses every letter) |
| F3 | Reset |
| Esc | Quit |

### DIP switches (`--dip`)

| Bits | Meaning |
| --- | --- |
| 0-1 | Lives: 3=2, 2=3, 1=4, 0=5 |
| 2 | Coinage |
| 3-4 | Difficulty: 0x18 easy … 0x00 hardest |
| 5 | Language: set = English |
| 6 | Bonus life: set = 30K, clear = 40K |
| 7 | Cabinet: set = upright |

Mikie has three banks (`--dip 0:0xff --dip 1:0x7b --dip 2:0xfe` are the defaults):
bank A holds coin A (low nibble) and coin B (high nibble), bank B holds lives (bits 0-1),
cabinet (bit 2), bonus life (bits 3-4), difficulty (bits 5-6) and demo sounds (bit 7),
and bank C holds flip screen (bit 0) and upright controls (bit 1).

Mikie ROM set: `n14.11c`, `o13.12a`, `o17.12d`, `n10.6e`, `o11.8i`, `001.f1`, `003.f3`,
`005.h1`, `007.h3`, `d19.1i`, `d21.3i`, `d20.2i`, `d22.12h`, `d18.f9`.

## Tests

```bash
ctest --test-dir build          # unit tests (CPU, PAL, graphics, palette, PSG)
```

The Z80 core can additionally be validated with the standard instruction exerciser,
which is not shipped here:

```bash
cmake --build build --target dsp_zexdoc
./build/dsp_zexdoc /path/to/zexdoc.com
```

## Layout

```
src/cpu/        Z80 and M6809 cores
src/sound/      AY-3-8910 and SN76496
src/video/      graphics decoding and resistor based palette helpers
src/machine/    Bagman PAL16R6, SLAPSTIC, Spectrum tape player
src/drivers/    the machines themselves (memory map, video, inputs)
src/frontend/   SDL2 front end, driven through the core/machine.h interface
src/core/       ROM loader (directory or zip) and the Machine interface
```

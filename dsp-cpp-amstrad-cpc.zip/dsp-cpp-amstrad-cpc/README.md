# Amstrad CPC 464/664/6128 driver port for [Chusogar/dsp-cpp](https://github.com/Chusogar/dsp-cpp)

This package ports the **Amstrad CPC 464/664/6128** home computer driver from
[leniad/dsp-emulator](https://github.com/leniad/dsp-emulator)
(`src/ordenadores/amstrad_cpc.pas`) into the C++17 + SDL2 emulator **dsp-cpp**.

> **Note:** This cloud agent was started on `Chusogar/EmulatorKit` and does not
> have write access to `Chusogar/dsp-cpp`. Apply the patch (or copy the files)
> into that repository and open the PR there.

## What was ported

| Component | Origin | New files in dsp-cpp |
| --- | --- | --- |
| Amstrad CPC driver | `amstrad_cpc.pas` | `src/drivers/amstrad_cpc.{h,cpp}` |
| Intel 8255 PPI | `ppi8255.pas` | `src/machine/i8255.{h,cpp}` (new generic, reusable chip) |
| Z80 @ 4 MHz | existing `src/cpu/z80` | reused |
| AY-3-8910 PSG | existing `src/sound/ay8910` | reused, spare I/O port A scans the keyboard |
| CDT/TZX cassette | existing `src/machine/spectrum_tape` | reused, clock compensated 4 MHz -> 3.5 MHz |

Also wired into `src/main.cpp`, `CMakeLists.txt`, `README.md` and unit tests.
`src/core/machine.h` gained three new shared `Key` enum values (`Escape`,
`Tab`, `CapsLock`) needed by the CPC keyboard matrix.

Hardware covered from the Pascal unit:

- Full memory map: lower/upper ROM enable, ROM slot selection (BASIC + AMSDOS),
  CPC6128's 128K bank switcher (`write_ram`)
- CRTC 6845 state machine: character/line counters, HSYNC/VSYNC generation,
  vertical total adjust, hardware scroll via the video RAM address wraparound
- Gate array: pen/palette selection (both colour and green-monitor DACs), video
  mode switch latched at end-of-line, ROM enable bits, 300 Hz (6/frame)
  interrupt generator synced to VSYNC
- All three video modes (0/1/2), rendered into a 400x312 ARGB framebuffer
  matching the original's border-inclusive canvas
- PPI ports A (AY-3-8910 bus)/B (VSYNC + cassette read, see note below)/C
  (AY control latch, cassette motor, keyboard row select)
- Keyboard matrix: every letter, digit, arrow, Enter/Space/Backspace/Tab/
  Escape/Shift/Ctrl/CapsLock (the CPC's shift+digit punctuation symbols and
  numeric keypad are out of scope, see the driver's doc comment)

### Two deliberate deviations from a byte-for-byte port

1. **Cassette read bit.** `port_b_read` in the source shifts the tape's EAR
   bit into bit 1 of the returned byte — but bit 1 is already forced to 1 by
   the `$7e` mask, so on the reference engine that line has no effect and, per
   its own comment (`bit 7 cassete data`), the intended position is bit 7.
   This port uses bit 7, so tape loading actually reads data.
2. **Joysticks off by default.** Real CPC hardware wires both joystick ports
   into keyboard matrix rows 6 and 9 (row 6 doubles with R/T/G/F/B/V/5/6, row
   9 with Backspace) — ported faithfully. But dsp-cpp's shared SDL front end
   hard-codes joystick 1/2 to fixed scancodes for arcade games (space,
   arrows, R/F/D/G/A/S...), which otherwise corrupts ordinary typing on a
   keyboard-driven machine. The driver only applies the joystick-to-matrix
   overlay when enabled via `--dip 1:1`; it is off by default so typing works
   out of the box.

## Scope not ported

FDC765 disk controller and `.dsk` images (a 6128 without a floppy still boots
into BASIC and runs anything that does not touch a disk), the Dandanator
cartridge, localized ROM variants (French/Spanish/Danish) and the CPC
Plus/512K silicon-disk RAM expansions.

## Apply to dsp-cpp

Preferred — fetch the ready-made commit from the git bundle (requires
dsp-cpp `main` at `d359849` or later that contains that commit as ancestor):

```bash
cd dsp-cpp
git fetch /path/to/dsp-cpp-amstrad-cpc/amstrad-cpc-driver.bundle cursor/amstrad-cpc-driver-7ed5:cursor/amstrad-cpc-driver-7ed5
git checkout cursor/amstrad-cpc-driver-7ed5
cmake -S . -B build -DCMAKE_BUILD_TYPE=Release
cmake --build build -j
ctest --test-dir build
./build/dsp --game cpc6128 /path/to/cpc6128.rom
git push -u origin cursor/amstrad-cpc-driver-7ed5   # then open the PR on dsp-cpp
```

Alternatives:

```bash
git checkout -b cursor/amstrad-cpc-driver-7ed5
git apply /path/to/dsp-cpp-amstrad-cpc/0001-Add-Amstrad-CPC-driver.patch
# or copy the files under src/, tests/, CMakeLists.txt and README.md over the tree
```

The commit SHA is recorded in `SOURCE_COMMIT.txt` (built against dsp-cpp `d359849`).

## Run

```bash
./build/dsp --game cpc6128 /path/to/cpc6128.rom
./build/dsp --game cpc464 --tape /path/to/game.cdt /path/to/cpc464.rom
./build/dsp --game cpc6128 --dip 0:0 /path/to/cpc6128.rom   # green monitor
./build/dsp --game cpc6128 --dip 1:1 /path/to/cpc6128.rom   # enable joysticks
```

ROMs are **not** included (`cpc464.rom` CRC `40852f25`, `cpc664.rom` CRC
`9ab5a036`, `cpc6128.rom` CRC `9e827fe1`, each 32K OS+BASIC; optional 16K
`amsdos.rom` CRC `1fe22ecd` for the 664/6128).

## Validation performed

- `cmake --build` and `ctest` pass (new `i8255` and Amstrad CPC unit tests)
- Headless screenshots: both CPC464 and CPC6128 boot to their correct
  model-specific BASIC banner (`Amstrad 64K Microcomputer (v1)` / `BASIC 1.0`
  and `Amstrad 128K Microcomputer (v3)` / `BASIC 1.1`), stable over 1500
  frames
- Interactive testing (SDL window, synthetic X11 key events): typing the full
  alphabet and digits, running `PRINT 11` and getting the `11` result back,
  all work with zero corruption after fixing the joystick/keyboard collision
  described above

## Contents of this package

- `amstrad-cpc-driver.bundle` — preferred: fetchable git commit for dsp-cpp
- `0001-Add-Amstrad-CPC-driver.patch` — single commit patch against dsp-cpp `main`
- Full copies of every new/modified file for review without applying the patch
- Updated `CMakeLists.txt`, `README.dsp-cpp.md` (project README) and `tests/tests.cpp`

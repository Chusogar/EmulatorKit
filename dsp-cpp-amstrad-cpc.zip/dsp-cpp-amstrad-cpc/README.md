# Amstrad CPC 464/664/6128 driver port (+ floppy disk) for [Chusogar/dsp-cpp](https://github.com/Chusogar/dsp-cpp)

This package ports the **Amstrad CPC 464/664/6128** home computer driver from
[leniad/dsp-emulator](https://github.com/leniad/dsp-emulator)
(`src/ordenadores/amstrad_cpc.pas`), including its **uPD765/NEC765 floppy disk
controller** (`src/devices/upd765.pas`) and **.dsk/.edsk loader**
(`src/misc/disk_file_format.pas`), into the C++17 + SDL2 emulator **dsp-cpp**.

> **Note:** This cloud agent was started on `Chusogar/EmulatorKit` and does not
> have write access to `Chusogar/dsp-cpp`. Apply the patches (or copy the
> files) into that repository and open the PR there.

## What was ported

| Component | Origin | New files in dsp-cpp |
| --- | --- | --- |
| Amstrad CPC driver | `amstrad_cpc.pas` | `src/drivers/amstrad_cpc.{h,cpp}` |
| Intel 8255 PPI | `ppi8255.pas` | `src/machine/i8255.{h,cpp}` (new generic, reusable chip) |
| uPD765/NEC765 FDC + .dsk/.edsk loader | `upd765.pas`, `disk_file_format.pas` | `src/machine/nec765.{h,cpp}` (new generic, reusable chip) |
| Z80 @ 4 MHz | existing `src/cpu/z80` | reused |
| AY-3-8910 PSG | existing `src/sound/ay8910` | reused, spare I/O port A scans the keyboard |
| CDT/TZX cassette | existing `src/machine/spectrum_tape` | reused, clock compensated 4 MHz -> 3.5 MHz |

Also wired into `src/main.cpp`, `CMakeLists.txt`, `README.md` and unit tests.
`src/core/machine.h` gained three new shared `Key` enum values (`Escape`,
`Tab`, `CapsLock`) needed by the CPC keyboard matrix.

Delivered as two commits/patches:

- `0001` — the driver itself (CPU, CRTC, gate array, PPI, AY-3-8910 keyboard,
  cassette).
- `0002` — the uPD765 FDC and `.dsk`/`.edsk` loading, wired into the driver's
  expansion I/O ports.

## Hardware covered

- Full memory map: lower/upper ROM enable, ROM slot selection (BASIC +
  AMSDOS), CPC6128's 128K bank switcher (`write_ram`)
- CRTC 6845 state machine: character/line counters, HSYNC/VSYNC generation,
  vertical total adjust, hardware scroll via the video RAM address wraparound
- Gate array: pen/palette selection (both colour and green-monitor DACs),
  video mode switch latched at end-of-line, ROM enable bits, 300 Hz (6/frame)
  interrupt generator synced to VSYNC
- All three video modes (0/1/2), rendered into a 400x312 ARGB framebuffer
  matching the original's border-inclusive canvas
- PPI ports A (AY-3-8910 bus)/B (VSYNC + cassette read)/C (AY control latch,
  cassette motor, keyboard row select)
- Keyboard matrix: every letter, digit, arrow, Enter/Space/Backspace/Tab/
  Escape/Shift/Ctrl/CapsLock (the CPC's shift+digit punctuation symbols and
  numeric keypad are out of scope)
- uPD765 FDC: RECALIBRATE, SEEK, SENSE INTERRUPT STATUS, SENSE DRIVE STATUS,
  SPECIFY, READ ID, READ TRACK, READ DATA/DELETED DATA (write commands update
  status/protection flags but do not persist data back to the image, matching
  the source engine)
- `.dsk`/Extended `.dsk` loading: track/sector tables, weak/multi sector
  copy protection, CRC based sector-size patches for Titus the Fox and
  Prehistorik

### Deliberate deviations from a byte-for-byte port

1. **Cassette read bit.** `port_b_read` in the source shifts the tape's EAR
   bit into bit 1 of the returned byte — but bit 1 is already forced to 1 by
   the `$7e` mask, so on the reference engine that line has no effect and, per
   its own comment (`bit 7 cassete data`), the intended position is bit 7.
   This port uses bit 7, so tape loading actually reads data.
2. **Joysticks off by default.** Real CPC hardware wires both joystick ports
   into keyboard matrix rows 6 and 9 (ported faithfully), but dsp-cpp's shared
   SDL front end hard-codes joystick scancodes to ordinary letters/space,
   which corrupts typing. Opt in with `--dip 1:1`.

Everything else, including the uPD765's ID-search characteristics described
below, is ported as-is.

## Scope not ported

The Dandanator cartridge, localized ROM variants (French/Spanish/Danish), the
CPC Plus/512K silicon-disk RAM expansions, the Oric `.dsk`/`.mfm` disk
variants and the Lenslock code-wheel protection (shows a UI dialog on the
source engine).

## Floppy disk: what was verified, and a known characteristic

Verified interactively against real `cpc6128.rom` + `amsdos.rom` (CRCs
`9e827fe1`/`1fe22ecd`), with the Z80 core running the actual AMSDOS ROM:

- RECALIBRATE, SEEK, SENSE INTERRUPT STATUS, READ ID and READ TRACK all work
  correctly end to end.
- **READ TRACK** (the whole-track sequential read most custom CPC game
  loaders use to load the actual game data fast) reads every sector in
  physical order and does not depend on the ID search below, so `.dsk` images
  built around fast loaders — the large majority of released games — load
  correctly.
- **AMSDOS's own `CAT`/`RUN"..."`** locate a file by ID search (`READ DATA`
  falling back on `find_sector`, `buscar_sector` in `upd765.pas`). That
  search's "sector currently under the head" position only advances on a
  `READ ID` command or an exact id match, is **not** reset by
  `SEEK`/`RECALIBRATE`, and gives up after checking a single sector instead of
  scanning the rest of the rotation on a plain id mismatch. This was cross
  checked by compiling `buscar_sector` standalone from the unmodified Pascal
  source with `fpc` and comparing outputs against this C++ port — they match
  exactly. In practice this means an interactive `CAT` against a disk whose
  directory sector isn't the one currently "under the head" can need several
  `Retry` presses (AMSDOS shows the real `Drive A: read fail` /
  `Retry, Ignore or Cancel?` prompt while doing so) or may not always succeed.
  This is the source engine's own shape for that code path, not a deviation
  introduced by this port — see the comment above `Nec765Fdc` in
  `src/machine/nec765.h` and the "Floppy disk" section of the updated
  dsp-cpp `README.md` in this package for the full detail.

## Apply to dsp-cpp

Preferred — fetch the ready-made commits from the git bundle (requires
dsp-cpp `main` at `d359849` or later that contains that commit as ancestor):

```bash
cd dsp-cpp
git fetch /path/to/dsp-cpp-amstrad-cpc/amstrad-cpc-driver.bundle cursor/amstrad-cpc-driver-7ed5:cursor/amstrad-cpc-driver-7ed5
git checkout cursor/amstrad-cpc-driver-7ed5
cmake -S . -B build -DCMAKE_BUILD_TYPE=Release
cmake --build build -j
ctest --test-dir build
./build/dsp --game cpc6128 --disk /path/to/game.dsk /path/to/cpc6128.rom
git push -u origin cursor/amstrad-cpc-driver-7ed5   # then open the PR on dsp-cpp
```

Alternatives:

```bash
git checkout -b cursor/amstrad-cpc-driver-7ed5
git am /path/to/dsp-cpp-amstrad-cpc/patches/*.patch
# or copy the files under src/, tests/, CMakeLists.txt and README.md over the tree
```

The commit SHAs are recorded in `SOURCE_COMMIT.txt` (built against dsp-cpp
`d359849`).

## Run

```bash
./build/dsp --game cpc6128 /path/to/cpc6128.rom
./build/dsp --game cpc464 --tape /path/to/game.cdt /path/to/cpc464.rom
./build/dsp --game cpc6128 --disk /path/to/game.dsk /path/to/cpc6128.rom
./build/dsp --game cpc6128 --dip 0:0 /path/to/cpc6128.rom   # green monitor
./build/dsp --game cpc6128 --dip 1:1 /path/to/cpc6128.rom   # enable joysticks
```

ROMs are **not** included (`cpc464.rom` CRC `40852f25`, `cpc664.rom` CRC
`9ab5a036`, `cpc6128.rom` CRC `9e827fe1`, each 32K OS+BASIC; optional 16K
`amsdos.rom` CRC `1fe22ecd` for the 664/6128).

## Validation performed

- `cmake --build` and `ctest` pass (new `i8255` and `nec765` unit tests,
  including a synthetic `.dsk` image round trip for READ ID/READ DATA/READ
  TRACK, plus Amstrad CPC machine metadata tests)
- Headless screenshots: both CPC464 and CPC6128 boot to their correct
  model-specific BASIC banner, stable over 1500 frames
- Interactive testing (SDL window, synthetic X11 key events): typing the full
  alphabet and digits, running `PRINT 11` and getting the `11` result back,
  all work with zero corruption after fixing the joystick/keyboard collision
  described above
- Interactive disk testing with real ROMs: `CAT` against a freshly-formatted,
  empty synthetic disk drives the FDC through RECALIBRATE/SEEK/SENSE
  INTERRUPT/READ ID/READ DATA exactly as expected and correctly surfaces
  AMSDOS's own `Drive A: read fail` / `Retry, Ignore or Cancel?` prompt when
  the ID search (see above) doesn't line up; a synthetic multi-sector image
  read back with READ TRACK returns every sector correctly

## Contents of this package

- `amstrad-cpc-driver.bundle` — preferred: fetchable git commits for dsp-cpp
- `patches/0001-*.patch`, `patches/0002-*.patch` — the two commits as patches
  against dsp-cpp `main` (driver, then FDC/disk support)
- Full copies of every new/modified file for review without applying the patches
- Updated `CMakeLists.txt`, `README.dsp-cpp.md` (project README) and `tests/tests.cpp`

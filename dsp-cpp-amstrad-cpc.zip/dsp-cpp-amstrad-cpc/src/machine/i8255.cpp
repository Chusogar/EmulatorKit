#include "machine/i8255.h"

#include <utility>

namespace dsp {

void I8255::set_port_handlers(PortRead port_a_read, PortRead port_b_read, PortRead port_c_read,
                              PortWrite port_a_write, PortWrite port_b_write,
                              PortWrite port_c_write) {
    port_a_read_ = std::move(port_a_read);
    port_b_read_ = std::move(port_b_read);
    port_c_read_ = std::move(port_c_read);
    port_a_write_ = std::move(port_a_write);
    port_b_write_ = std::move(port_b_write);
    port_c_write_ = std::move(port_c_write);
}

void I8255::reset() { control_ = 0x9b; }

uint8_t I8255::read(int port) {
    switch (port) {
        case 0: return port_a_read_ ? port_a_read_() : 0xff;
        case 1: return port_b_read_ ? port_b_read_() : 0xff;
        case 2: return port_c_read_ ? port_c_read_() : 0xff;
        default: return control_;
    }
}

void I8255::write(int port, uint8_t value) {
    switch (port) {
        case 0:
            if (port_a_write_) port_a_write_(value);
            break;
        case 1:
            if (port_b_write_) port_b_write_(value);
            break;
        case 2:
            if (port_c_write_) port_c_write_(value);
            break;
        default:
            control_ = value;
            break;
    }
}

}  // namespace dsp

#pragma once

#include <cstdint>
#include <functional>

namespace dsp {

// Intel 8255 Programmable Peripheral Interface, ported from ppi8255.pas.
// Only mode 0 basic I/O is needed by the drivers that use it: the control
// register is stored but, like the source emulator, is not consulted to
// decide a port's direction. Every access is forwarded straight to the
// driver's callback for that port, which is expected to configure the chip
// correctly (real firmware always does).
class I8255 {
public:
    using PortRead = std::function<uint8_t()>;
    using PortWrite = std::function<void(uint8_t)>;

    void set_port_handlers(PortRead port_a_read, PortRead port_b_read, PortRead port_c_read,
                           PortWrite port_a_write, PortWrite port_b_write,
                           PortWrite port_c_write);

    void reset();

    // `port` is 0 = A, 1 = B, 2 = C, 3 = control register.
    uint8_t read(int port);
    void write(int port, uint8_t value);

private:
    uint8_t control_ = 0x9b;  // ports A/B/C input, mode 0 (power-on default)

    PortRead port_a_read_;
    PortRead port_b_read_;
    PortRead port_c_read_;
    PortWrite port_a_write_;
    PortWrite port_b_write_;
    PortWrite port_c_write_;
};

}  // namespace dsp

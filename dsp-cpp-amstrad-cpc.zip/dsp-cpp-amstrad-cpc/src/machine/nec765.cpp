#include "machine/nec765.h"

#include <algorithm>
#include <cstdio>
#include <cstring>
#include <fstream>

#include "core/rom_loader.h"

namespace dsp {
namespace {

// Number of command bytes for each NEC765 command, indexed by (opcode & 0x1f),
// bytes_in_cmd of upd765.pas.
constexpr uint8_t kBytesInCmd[32] = {1, 1, 9, 3, 2, 9, 9, 2, 1, 9, 2, 1, 9, 6, 1, 3,
                                     1, 9, 1, 1, 1, 1, 1, 1, 1, 9, 1, 1, 1, 1, 9, 1};

uint16_t read_u16(const uint8_t* p) { return uint16_t(p[0] | (p[1] << 8)); }

bool magic_is(const uint8_t* p, const char* text, size_t length) {
    return std::memcmp(p, text, length) == 0;
}

}  // namespace

Nec765Fdc::Nec765Fdc() { reset(); }

bool Nec765Fdc::disk_inserted(int drive) const {
    return drive >= 0 && drive < kDriveCount && disks_[size_t(drive)].open;
}

void Nec765Fdc::eject_disk(int drive) {
    if (drive < 0 || drive >= kDriveCount) return;
    disks_[size_t(drive)] = Disk{};
}

bool Nec765Fdc::load_disk(int drive, const std::string& path, std::string* error) {
    std::ifstream stream(path, std::ios::binary);
    if (!stream) {
        if (error != nullptr) *error = "cannot open " + path;
        return false;
    }
    std::vector<uint8_t> data((std::istreambuf_iterator<char>(stream)),
                              std::istreambuf_iterator<char>());
    if (data.empty()) {
        if (error != nullptr) *error = path + " is empty";
        return false;
    }
    return load_disk_from_memory(drive, data, error);
}

bool Nec765Fdc::load_disk_from_memory(int drive, const std::vector<uint8_t>& data,
                                      std::string* error) {
    if (drive < 0 || drive >= kDriveCount) {
        if (error != nullptr) *error = "invalid drive number";
        return false;
    }
    Disk fresh;
    if (!parse_dsk(fresh, data, error)) return false;
    disks_[size_t(drive)] = std::move(fresh);
    return true;
}

// Ported from dsk_format() of disk_file_format.pas. Understands the standard
// "MV - CPC" and "EXTENDED" .dsk layouts; the Oric .dsk/.mfm variants of that
// function are out of scope for the CPC.
bool Nec765Fdc::parse_dsk(Disk& disk, const std::vector<uint8_t>& raw, std::string* error) {
    if (raw.size() < 0x100) {
        if (error != nullptr) *error = "file too small to be a .dsk image";
        return false;
    }
    const uint8_t* base = raw.data();
    const uint32_t file_length = uint32_t(raw.size());

    bool standard;
    if (magic_is(base, "MV - CPC", 8)) {
        standard = true;
    } else if (magic_is(base, "EXTENDED", 8)) {
        standard = false;
    } else {
        if (error != nullptr) *error = "not a .dsk/.edsk image (bad signature)";
        return false;
    }

    const uint8_t header_tracks = base[0x30];
    const uint8_t header_sides = base[0x31];
    const uint16_t header_track_size = read_u16(base + 0x32);
    if (header_sides == 0 || header_sides > 2 || header_tracks == 0) {
        if (error != nullptr) *error = "unsupported disk geometry";
        return false;
    }

    disk.tracks_count = header_tracks;
    disk.heads_count = header_sides;

    // track_size_table[side][track], filled track-major like dsk_format().
    std::array<std::array<uint8_t, 132>, 2> track_size_table{};
    {
        size_t map_index = 0;
        for (uint8_t track_num = 0; track_num < header_tracks; track_num++) {
            for (uint8_t side_num = 0; side_num < header_sides; side_num++) {
                if (0x34 + map_index < raw.size() && side_num < 2 && track_num < 132) {
                    track_size_table[side_num][track_num] = base[0x34 + map_index];
                }
                map_index++;
            }
        }
    }

    bool has_multi = false;
    uint32_t offset = 0x100;
    while (offset < file_length) {
        if (offset + 24 > file_length) break;
        const uint8_t* track_header = base + offset;
        if (!magic_is(track_header, "Track-Info", 10)) break;

        const uint8_t track_num = track_header[16];
        const uint8_t side_num = track_header[17];
        const uint8_t data_rate = track_header[18];
        const uint8_t record_mode = track_header[19];
        const uint8_t sector_size = track_header[20];
        const uint8_t number_of_sectors = track_header[21];
        const uint8_t gap = track_header[22];
        const uint8_t filler = track_header[23];
        if (side_num >= 2 || track_num >= disk.tracks[0].size()) return false;

        TrackInfo& track = disk.tracks[side_num][track_num];
        track.track_number = track_num;
        track.side_number = side_num;
        track.data_rate = data_rate;
        track.recording_mode = record_mode;
        track.sector_size = sector_size;
        track.number_sector = number_of_sectors;
        track.gap3 = gap;
        track.filler = filler;

        uint32_t position = 0;
        uint32_t sector_ptr = offset + 24;
        const uint8_t sectors_to_read =
            uint8_t(std::min<uint32_t>(number_of_sectors, track.sectors.size()));
        for (uint8_t sector_count = 0; sector_count < sectors_to_read; sector_count++) {
            if (sector_ptr + 8 > file_length) break;
            const uint8_t* sd = base + sector_ptr;
            sector_ptr += 8;

            SectorInfo& sector = track.sectors[sector_count];
            sector.track = sd[0];
            sector.head = sd[1];
            sector.sector = sd[2];
            sector.sector_size = sd[3];
            sector.status1 = sd[4];
            sector.status2 = sd[5];
            sector.data_length =
                standard ? uint16_t(1u << (sd[3] + 7)) : read_u16(sd + 6);
            sector.position = position;
            position += sector.data_length;

            const uint32_t nominal = 1u << (sd[3] + 7);
            uint32_t multiplicity = nominal != 0 ? sector.data_length / nominal : 0;
            if (multiplicity > 1) {
                if (multiplicity > 4) multiplicity = 4;
                sector.multi = true;
                disk.multi_counter = uint8_t(multiplicity);
                disk.multi_max = uint8_t(multiplicity);
                has_multi = true;
            }
        }

        offset += 0x100;  // the 256 byte track header block

        // Find how many data bytes belong to this track: scan forward until the
        // next "Track-Info" block or end of file, mirroring dsk_format()'s
        // linear scan (there is no reliable way to compute it from the sector
        // table alone for every .dsk in the wild).
        uint32_t track_long = 0;
        uint32_t scan = offset;
        while (scan < file_length) {
            if (scan + 24 <= file_length && magic_is(base + scan, "Track-Info", 10)) break;
            track_long++;
            scan++;
        }

        if (track_size_table[side_num][track_num] != 0) {
            track.track_length = 256u * (uint32_t(track_size_table[side_num][track_num]) - 1);
        } else if (!standard) {
            track.track_length = track_long;
        } else {
            // Preserves the source engine's standard-.dsk sizing exactly,
            // including its header-inclusive track_size (a quirk of the
            // original dsk_format(), kept for fidelity).
            track.track_length = header_track_size;
        }

        const uint32_t available = file_length - offset;
        const uint32_t to_copy = std::min(track.track_length, available);
        track.data.assign(base + offset, base + offset + to_copy);

        offset += track.track_length;
    }

    apply_protection_patches(disk, has_multi);
    disk.open = true;
    disk.write_protected = false;
    return true;
}

// Ported from check_protections() of disk_file_format.pas: only the CRC based
// sector-size patches used on the Amstrad CPC branch of that function
// (Titus the Fox, Prehistorik). The Lenslock code-wheel titles show a UI
// dialog on the source engine and are not ported.
void Nec765Fdc::apply_protection_patches(Disk& disk, bool /*has_multi*/) {
    TrackInfo& track0 = disk.tracks[0][0];
    if (track0.data.empty()) return;
    if (track0.sectors[0].data_length == 0 ||
        track0.sectors[0].data_length > track0.data.size()) {
        return;
    }
    const uint32_t crc = crc32_of(track0.data.data(), track0.sectors[0].data_length);
    switch (crc) {
        case 0x8c817e25:
        case 0x4b616c83:  // Titus the Fox
            if (disk.tracks[0].size() > 40) disk.tracks[0][40].sectors[6].sector_size = 2;
            break;
        case 0x57a3276f:  // Prehistorik
            if (disk.tracks[0].size() > 39) disk.tracks[0][39].sectors[10].sector_size = 0;
            break;
        case 0xf05fe06e:  // Prehistorik (alt)
            if (disk.tracks[0].size() > 39) disk.tracks[0][39].sectors[0].sector_size = 2;
            break;
        default:
            break;
    }
}

void Nec765Fdc::reset() {
    floppy_motor_ = false;
    command_pointer_ = 0;
    exec_cmd_phase_ = false;
    result_phase_ = false;
    status_register_ = 0x80;
    command_.fill(0);
    result_.fill(0);
    seek_track_flag_ = false;
    st0_ = st1_ = st2_ = st3_ = 0;
    result_pointer_ = 0;
    result_counter_ = 0;
    data_pointer_ = 0;
    data_length_ = 0;
    counter_ = 0;
    status_counter_ = 0;
    read_status_counter_ = 0;
    // Important for weak-sector protection even before a disk is inserted.
    for (Disk& disk : disks_) {
        disk.multi_counter = 3;
        disk.multi_max = 3;
    }
}

void Nec765Fdc::write_motor(uint8_t value) { floppy_motor_ = value != 0; }

void Nec765Fdc::get_result7() {
    Disk& disk = disks_[current_drive_];
    const TrackInfo& track = disk.tracks[disk.side_actual][disk.track_actual];
    const SectorInfo& sector = track.sectors[disk.sector_actual];
    result_[0] = st0_;
    result_[1] = st1_;
    result_[2] = st2_;
    result_[3] = sector.track;
    result_[4] = sector.head;
    result_[5] = sector.sector;
    result_[6] = sector.sector_size;
    status_register_ = 0xd0;
    result_pointer_ = 0;
    result_counter_ = 7;
    st0_ = st1_ = st2_ = 0;
    exec_cmd_phase_ = false;
    result_phase_ = true;
}

bool Nec765Fdc::find_sector() {
    Disk& disk = disks_[current_drive_];
    TrackInfo& track = disk.tracks[disk.side_actual][disk.track_actual];
    if (track.number_sector == 0) return true;

    int index_count = 0;
    while (index_count != 2) {
        if (uint32_t(disk.sector_actual) + 1 > track.number_sector) {
            disk.sector_actual = 0;
            index_count++;
        }
        SectorInfo& sector = track.sectors[disk.sector_actual];
        if (sector.sector == command_[4]) {
            if (sector.track == command_[2]) {
                if (sector.head == command_[3]) {
                    if (sector.sector_size == command_[5]) {
                        if (command_[4] == command_[6]) st1_ |= 0x80;
                        st1_ |= uint8_t(sector.status1 & 0x20);
                        st2_ |= uint8_t(sector.status1 & 0x60);
                        return true;
                    }
                    st1_ |= 0x80;
                    return true;
                }
            }
        } else {
            st1_ |= 0x04;   // NEC765_ST1_NO_DATA
            st2_ |= 0x10;   // NEC765_ST2_WRONG_CYLINDER
            if (sector.track == 0xff) st2_ |= 0x02;  // NEC765_ST2_BAD_CYLINDER
            return true;
        }
        disk.sector_actual++;
    }
    return false;
}

bool Nec765Fdc::should_skip_sector() const {
    const Disk& disk = disks_[current_drive_];
    const TrackInfo& track = disk.tracks[disk.side_actual][disk.track_actual];
    const SectorInfo& sector = track.sectors[disk.sector_actual];
    if ((command_[0] & 0x20) != 0) {
        if ((command_[0] & 0x1f) == 0x06) {
            if ((sector.status2 & 0x40) != 0) return true;
        } else if ((command_[0] & 0x1f) == 0x0c) {
            if ((sector.status2 & 0x40) == 0) return true;
        }
    }
    return false;
}

void Nec765Fdc::start_read_sector() {
    Disk& disk = disks_[current_drive_];
    bool done = false;
    while (!done) {
        if (find_sector()) {
            if (should_skip_sector()) {
                if (command_[4] == command_[6]) {
                    st1_ &= 0x7f;
                    get_result7();
                    return;
                }
                command_[4]++;
            } else {
                done = true;
            }
        } else {
            st0_ |= 0x40;
            st1_ |= 0x04;
            get_result7();
            return;
        }
    }
    exec_cmd_phase_ = true;
    TrackInfo& track = disk.tracks[disk.side_actual][disk.track_actual];
    SectorInfo& sector = track.sectors[disk.sector_actual];
    if (sector.multi) {
        if (disk.multi_counter >= disk.multi_max - 1) disk.multi_counter = 0;
        else disk.multi_counter++;
        data_pointer_ = sector.position +
                       uint32_t(disk.multi_counter) * (1u << (sector.sector_size + 7));
    } else {
        data_pointer_ = sector.position;
    }
    data_length_ = 1u << (command_[5] + 7);
    if (command_[5] == 0) {
        data_length_ = command_[8];
        if (data_length_ > 0x80) data_length_ = 0x80;
    }
    counter_ = 0;
    status_register_ = 0xf0;
}

void Nec765Fdc::start_read_track() {
    Disk& disk = disks_[current_drive_];
    data_length_ = 1u << (command_[5] + 7);
    data_pointer_ =
        disk.tracks[disk.side_actual][disk.track_actual].sectors[disk.sector_read_track].position;
    counter_ = 0;
    exec_cmd_phase_ = true;
    status_register_ = 0xf0;
}

void Nec765Fdc::select_drive() {
    current_drive_ = uint8_t(command_[1] & 1);
    Disk& disk = disks_[current_drive_];
    disk.side_actual = uint8_t((command_[1] & 4) >> 2);
    st0_ = uint8_t(st0_ & 0xf8);
    st3_ = uint8_t(st3_ & 0xf8);
    st0_ = uint8_t(st0_ | (command_[1] & 1) | (command_[1] & 4));
    st3_ = uint8_t(st3_ | (command_[1] & 1) | (command_[1] & 4));
}

bool Nec765Fdc::seek_track(uint8_t track) {
    Disk& disk = disks_[current_drive_];
    const bool ok = int(track) <= int(disk.tracks_count) - 1;
    disk.track_actual = ok ? track : disk.tracks_count;
    return ok;
}

void Nec765Fdc::exec_write_command() {
    switch (command_[0] & 0x1f) {
        case 2: {  // Read track
            st0_ = 0;
            st1_ = 0x04;
            st2_ = 0;
            select_drive();
            if (!disks_[current_drive_].open) {
                st0_ |= 0x48;
                get_result7();
            } else {
                disks_[current_drive_].sector_read_track = 0;
                start_read_track();
            }
            break;
        }
        case 3:  // Specify
            exec_cmd_phase_ = false;
            result_phase_ = false;
            status_register_ = uint8_t(status_register_ & (0x40 + 0x20 + 0x10));
            status_register_ |= 0x80;
            break;
        case 4: {  // Sense drive status
            current_drive_ = uint8_t(command_[1] & 1);
            Disk& drive = disks_[current_drive_];
            st3_ |= uint8_t((command_[1] & 1) | (command_[1] & 4));
            if (drive.write_protected) st3_ |= 0x40;
            if (drive.open) st3_ |= 0x20;
            if (drive.track_actual == 0) st3_ |= 0x10;
            st3_ = uint8_t(st3_ | (drive.heads_count << 4));
            result_counter_ = 1;
            result_pointer_ = 0;
            result_[0] = st3_;
            exec_cmd_phase_ = false;
            result_phase_ = true;
            status_register_ |= 0x40;
            status_register_ = uint8_t(status_register_ & 0x20);
            break;
        }
        case 5:
        case 9: {  // Write data / deleted data (partial: no actual data transfer)
            st0_ = st1_ = st2_ = 0;
            select_drive();
            if (!disks_[current_drive_].open) {
                st0_ |= 0x48;
                get_result7();
                break;
            }
            if (disks_[current_drive_].write_protected) {
                st0_ |= 0x40;
                st1_ |= 0x02;
                get_result7();
                break;
            }
            st0_ = st1_ = st2_ = 0;
            select_drive();
            break;
        }
        case 6:
        case 12: {  // Read data / deleted data
            st0_ = st1_ = st2_ = 0;
            select_drive();
            if (!disks_[current_drive_].open) {
                st0_ |= 0x48;
                get_result7();
            } else {
                start_read_sector();
            }
            break;
        }
        case 7: {  // Recalibrate
            st0_ = 0x20;
            st1_ = 0;
            st2_ = 0;
            select_drive();
            status_register_ = 0x80;
            seek_track_flag_ = true;
            if (!disks_[current_drive_].open) st0_ |= 0x48;
            else seek_track(0);
            exec_cmd_phase_ = false;
            break;
        }
        case 8: {  // Sense interrupt status
            result_pointer_ = 0;
            st0_ = uint8_t(st0_ & 0xf8);
            if (seek_track_flag_) {
                st0_ |= 0x20;
                result_counter_ = 2;
                seek_track_flag_ = false;
                result_[1] = disks_[current_drive_].track_actual;
                result_[0] = st0_;
            } else {
                st0_ = 0x80;
                result_counter_ = 1;
                result_[0] = st0_;
            }
            status_register_ = 0xd0;
            exec_cmd_phase_ = false;
            result_phase_ = true;
            break;
        }
        case 10: {  // Read ID of next sector
            st0_ = st1_ = st2_ = 0;
            select_drive();
            Disk& drive = disks_[current_drive_];
            TrackInfo& track = drive.tracks[drive.side_actual][drive.track_actual];
            if (!drive.open) {
                st0_ = 0x48;
                get_result7();
            } else if (track.number_sector == 0) {
                // Lets +3 titles like 'Tomahawk' work.
                st1_ = 1;
                get_result7();
                result_[3] = drive.track_actual;
                result_[4] = 0;
                result_[5] = 0;
                result_[6] = 0;
            } else {
                // Essential for e.g. 'Tintin on the Moon'.
                if (uint32_t(drive.sector_actual) + 1 > track.number_sector) {
                    drive.sector_actual = 0;
                }
                get_result7();
                drive.sector_actual++;
            }
            break;
        }
        case 15: {  // Seek
            select_drive();
            status_register_ = 0x80;
            seek_track_flag_ = true;
            st0_ = 0x20;
            st1_ = 0;
            st2_ = 0;
            if (!disks_[current_drive_].open) st0_ |= 0x48;
            else seek_track(command_[2]);
            exec_cmd_phase_ = false;
            break;
        }
        default: {
            result_counter_ = 1;
            result_pointer_ = 0;
            st0_ = uint8_t(0x80 | st0_);
            if (exec_cmd_phase_) {  // Timeout, needed for the Hexagon protection
                st1_ |= 0x10;
                st0_ = uint8_t((st0_ & 0x3f) | 0x40);
                status_register_ = 0x80;
            }
            result_[0] = st0_;
            exec_cmd_phase_ = false;
            result_phase_ = true;
            seek_track_flag_ = true;
            break;
        }
    }
}

bool Nec765Fdc::read_data_should_stop() {
    Disk& disk = disks_[current_drive_];
    TrackInfo& track = disk.tracks[disk.side_actual][disk.track_actual];
    SectorInfo& sector = track.sectors[disk.sector_actual];
    bool stop = false;
    if ((command_[0] & 0x20) == 0) {
        if ((command_[0] & 0x1f) == 0x06) {
            if ((sector.status2 & 0x40) != 0) {
                st2_ |= 0x40;  // NEC765_ST2_CONTROL_MARK
                stop = true;
            }
        } else if ((command_[0] & 0x1f) == 0x0c) {
            if ((sector.status2 & 0x40) == 0) {
                st2_ |= 0x40;
                stop = true;
            }
        }
    }
    if ((sector.status1 & 0x20) != 0) {
        st1_ |= 0x20;
        stop = true;
    }
    return stop;
}

uint8_t Nec765Fdc::exec_read_command() {
    Disk& disk = disks_[current_drive_];
    switch (command_[0] & 0x1f) {
        case 2: {  // Read track
            TrackInfo& track = disk.tracks[disk.side_actual][disk.track_actual];
            if (track.data.empty()) {
                st0_ = 0x40 + 0x80;
                st1_ = 0 + 0x20;
                st2_ = 1;
                get_result7();
                return 0;
            }
            const uint8_t value =
                data_pointer_ < track.data.size() ? track.data[data_pointer_] : 0xff;
            data_pointer_++;
            counter_++;
            if (counter_ == data_length_) {
                if (disk.sector_read_track == uint8_t(command_[6] - 1)) {
                    st1_ |= 0x80;
                    get_result7();
                } else {
                    disk.sector_read_track++;
                    start_read_track();
                }
            }
            return value;
        }
        case 6:
        case 12: {  // Read data / deleted data
            TrackInfo& track = disk.tracks[disk.side_actual][disk.track_actual];
            if (track.data.empty()) {
                st0_ = 0x40 + 0x80;
                st1_ = 0x20;
                st2_ = 1;
                get_result7();
                status_register_ = 0xd0 + 0x20;
                return 0;
            }
            SectorInfo& sector = track.sectors[disk.sector_actual];
            if (counter_ >= (1u << (sector.sector_size + 7))) {
                // Speedlock (Amstrad) and some Titus protections rely on this.
                st0_ = 0x40;
                st1_ = 0x04;
                st2_ = 0;
                get_result7();
                return 0;
            }
            const uint8_t value =
                data_pointer_ < track.data.size() ? track.data[data_pointer_] : 0xff;
            data_pointer_++;
            counter_++;
            if (counter_ == data_length_) {
                if (command_[4] == command_[6] || read_data_should_stop()) {
                    st0_ |= 0x40;
                    // Can't buffer more than 6304 bytes, needed for
                    // 'Defender of the Crown' on the Amstrad.
                    if (sector.sector_size > 5) st1_ = 0x20;
                    get_result7();
                } else {
                    command_[4]++;
                    start_read_sector();
                }
            }
            return value;
        }
        default:
            return 0;
    }
}

uint8_t Nec765Fdc::get_result() {
    const uint8_t value = result_[result_pointer_];
    result_pointer_++;
    if (result_pointer_ == result_counter_) {
        status_register_ = 0x80;
        result_phase_ = false;
        result_.fill(0);
        command_.fill(0);
    }
    return value;
}

void Nec765Fdc::write_data(uint8_t value) {
    status_counter_ = 0;
    if (!exec_cmd_phase_ || !result_phase_) {
        if (command_pointer_ == 0) {
            command_[0] = value;
            command_pointer_++;
            status_register_ |= 0x10;
        } else if (command_pointer_ < kBytesInCmd[command_[0] & 0x1f]) {
            command_[size_t(command_pointer_)] = value;
            command_pointer_++;
        }
        if (command_pointer_ == kBytesInCmd[command_[0] & 0x1f]) {
            command_pointer_ = 0;
            status_register_ |= 0x20;
            exec_write_command();
        }
    } else {
        exec_write_command();
    }
}

uint8_t Nec765Fdc::read_data() {
    status_counter_ = 0;
    if (exec_cmd_phase_) return exec_read_command();
    if (result_phase_) return get_result();
    return 0;
}

uint8_t Nec765Fdc::read_status() {
    status_counter_++;
    if (status_counter_ > 0x10) {
        if (seek_track_flag_) {
            read_status_counter_++;
            if (read_status_counter_ > 0x20) {
                status_register_ = 0xc0;
                if (read_status_counter_ > 0x40) read_status_counter_ = 0;
            } else {
                status_register_ = 0x50;
            }
            seek_track_flag_ = false;
        } else {
            status_register_ = 0xf0;
            st0_ = uint8_t((st0_ & 0x3f) | 0x40);
            st1_ |= 0x10;
            seek_track_flag_ = true;
        }
        command_pointer_ = 0;
        status_counter_ = 0;
    }
    return status_register_;
}

}  // namespace dsp
